import os
import psycopg2
from dotenv import load_dotenv

load_dotenv()
DATABASE_URL = os.getenv('DATABASE_URL')


def connect():
    return psycopg2.connect(DATABASE_URL)


def is_exists(name):
    conn = connect()
    with conn.cursor() as curs:
        curs.execute('SELECT * FROM urls WHERE name = %s', (name,))
        db_answer = curs.fetchone()
    return True if db_answer else False


def add_url(url):
    conn = connect()
    with conn.cursor() as curs:
        curs.execute('INSERT INTO urls (name) VALUES (%s) RETURNING id',
                     (url,))
        id_, = curs.fetchone()
        conn.commit()
    return id_


def get_items(table_name):
    conn = connect()
    with conn.cursor() as curs:
        head = curs.execute(
            f'SELECT column_name '
            f'FROM INFORMATION_SCHEMA.COLUMNS'
            f'WHERE TABLE_NAME={table_name}'
        )
        body = curs.execute(f'SELECT * FROM {table_name}')
        for title in head:
            {
                f'title'
            }

        return curs.fetchone()
